# Netflix-Party Chrome Extension

This will be how parties will interface with one another